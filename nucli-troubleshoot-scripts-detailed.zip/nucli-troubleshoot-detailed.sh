#!/bin/bash

# Script de Troubleshooting para NuCLI e AWS
# Versão detalhada que mostra comandos e suas finalidades
# Executa correções automáticas quando problemas são detectados
# Baseado no documento de troubleshooting NuCLI and AWS Errors

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
NC='\033[0m' # No Color

# Arrays para armazenar resultados dos comandos executados
declare -a COMMAND_SUCCESS=()
declare -a COMMAND_FAILED=()
declare -a COMMAND_NEEDS_ACTION=()

# Função para imprimir cabeçalho
print_header() {
    echo -e "${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}"
}

# Função para imprimir sucesso
print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

# Função para imprimir erro
print_error() {
    echo -e "${RED}✗ $1${NC}"
}

# Função para imprimir aviso
print_warning() {
    echo -e "${YELLOW}⚠ $1${NC}"
}

# Função para imprimir informação
print_info() {
    echo -e "${BLUE}ℹ $1${NC}"
}

# Função para mostrar comando antes de executar
print_command() {
    echo ""
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${MAGENTA}📋 COMANDO:${NC} ${YELLOW}$1${NC}"
    echo -e "${MAGENTA}🎯 FINALIDADE:${NC} $2"
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
}

# Funções para registrar resultados dos comandos
register_command_success() {
    local cmd="$1"
    local output="${2:-}"
    COMMAND_SUCCESS+=("$cmd|$output")
}

register_command_failed() {
    local cmd="$1"
    local reason="${2:-}"
    COMMAND_FAILED+=("$cmd|$reason")
}

register_command_needs_action() {
    local cmd="$1"
    local reason="${2:-}"
    COMMAND_NEEDS_ACTION+=("$cmd|$reason")
}

# Função para executar comando e mostrar resultado
execute_command() {
    local cmd="$1"
    local purpose="$2"
    local show_output="${3:-true}"
    
    print_command "$cmd" "$purpose"
    
    if [ "$show_output" = "true" ]; then
        echo -e "${BLUE}📤 Executando...${NC}"
        eval "$cmd"
        local exit_code=$?
        
        if [ $exit_code -eq 0 ]; then
            echo -e "${GREEN}✓ Comando executado com sucesso (código: $exit_code)${NC}"
        else
            echo -e "${RED}✗ Comando falhou (código: $exit_code)${NC}"
        fi
        return $exit_code
    else
        eval "$cmd" &> /dev/null
        local exit_code=$?
        
        if [ $exit_code -eq 0 ]; then
            echo -e "${GREEN}✓ Comando executado com sucesso (código: $exit_code)${NC}"
        else
            echo -e "${RED}✗ Comando falhou (código: $exit_code)${NC}"
        fi
        return $exit_code
    fi
}

# Função para executar comandos interativos permitindo interação do usuário
execute_interactive_user_command() {
    local cmd="$1"
    local purpose="$2"
    
    print_command "$cmd" "$purpose (modo interativo - aguardando interação do usuário)"
    echo ""
    print_info "Este comando requer interação manual. Você poderá interagir diretamente."
    echo ""
    print_warning "Pressione Ctrl+C para cancelar se necessário."
    echo ""
    read -p "Pressione Enter para executar o comando interativo..." dummy
    echo ""
    
    # Executar o comando permitindo interação completa do usuário
    eval "$cmd"
    local exit_code=$?
    
    echo ""
    if [ $exit_code -eq 0 ]; then
        print_success "Comando interativo executado com sucesso"
        register_command_success "$cmd" "Executado com interação do usuário"
    else
        print_error "Comando interativo retornou código: $exit_code"
        register_command_failed "$cmd" "Código de saída: $exit_code (após interação do usuário)"
    fi
    
    return $exit_code
}

# Função para executar comandos interativos de forma automatizada
execute_interactive_command() {
    local cmd="$1"
    local purpose="$2"
    local timeout_seconds="${3:-30}"
    
    print_command "$cmd" "$purpose (modo interativo automatizado com timeout de ${timeout_seconds}s)"
    
    # Verificar se timeout está disponível (macOS pode ter gtimeout)
    local timeout_cmd=""
    if command -v timeout &> /dev/null; then
        timeout_cmd="timeout"
    elif command -v gtimeout &> /dev/null; then
        timeout_cmd="gtimeout"
    else
        print_warning "Comando 'timeout' não disponível. Tentando sem timeout..."
    fi
    
    echo -e "${BLUE}📤 Executando com timeout de ${timeout_seconds}s...${NC}"
    print_warning "Se o comando pedir confirmação interativa, pode não funcionar automaticamente."
    
    # Tentar executar com expect se disponível (melhor opção para automação)
    if command -v expect &> /dev/null; then
        print_info "Usando 'expect' para automação interativa..."
        expect << EXPECT_EOF 2>&1 | head -100
set timeout $timeout_seconds
spawn bash -c "$cmd"
expect {
    -re ".*[Yy]es/[Nn]o.*" { 
        send "yes\r"
        exp_continue 
    }
    -re ".*[Yy]/[Nn].*" { 
        send "y\r"
        exp_continue 
    }
    -re ".*password.*" { 
        send "\r"
        exp_continue 
    }
    -re ".*Password.*" { 
        send "\r"
        exp_continue 
    }
    -re ".*continue.*" { 
        send "\r"
        exp_continue 
    }
    -re ".*proceed.*" { 
        send "\r"
        exp_continue 
    }
    -re ".*Press.*" { 
        send "\r"
        exp_continue 
    }
    timeout { 
        puts "Timeout após ${timeout_seconds}s"
        exit 124
    }
    eof
}
catch wait result
exit [lindex \$result 3]
EXPECT_EOF
        local exit_code=$?
    elif [ -n "$timeout_cmd" ]; then
        # Fallback: usar timeout com entrada automática (múltiplos Enters)
        print_info "Usando 'timeout' com entrada automática..."
        (
            # Enviar múltiplos Enters para responder prompts
            for i in {1..10}; do
                echo ""
                sleep 0.2
            done
        ) | $timeout_cmd "$timeout_seconds" bash -c "$cmd" 2>&1 | head -100
        local exit_code=$?
    else
        # Sem timeout disponível - executar diretamente mas limitar saída
        print_warning "Executando sem timeout (pode travar se for muito interativo)..."
        bash -c "$cmd" 2>&1 | head -100 &
        local cmd_pid=$!
        sleep "$timeout_seconds"
        if kill -0 "$cmd_pid" 2>/dev/null; then
            kill "$cmd_pid" 2>/dev/null
            exit_code=124
        else
            wait "$cmd_pid"
            exit_code=$?
        fi
    fi
    
    if [ $exit_code -eq 0 ]; then
        echo -e "${GREEN}✓ Comando interativo executado com sucesso${NC}"
    elif [ $exit_code -eq 124 ]; then
        echo -e "${YELLOW}⚠ Comando interativo atingiu timeout de ${timeout_seconds}s${NC}"
        print_info "O comando pode precisar de interação manual. Execute: $cmd"
    else
        echo -e "${YELLOW}⚠ Comando interativo retornou código: $exit_code${NC}"
        print_info "Pode ter funcionado parcialmente ou requerido interação manual."
        print_info "Para executar manualmente: $cmd"
    fi
    
    return $exit_code
}

# Verificar se o NuCLI está instalado
check_nucli_installation() {
    print_header "Verificando instalação do NuCLI"
    
    print_info "Verificando se o comando 'nu' está disponível no sistema..."
    
    execute_command "command -v nu" \
        "Verifica se o comando 'nu' está instalado e disponível no PATH do sistema" \
        "false"
    
    if [ $? -eq 0 ]; then
        print_success "NuCLI está instalado"
        register_command_success "command -v nu" "NuCLI encontrado no PATH"
        
        execute_command "nu --version" \
            "Obtém a versão do NuCLI instalado, incluindo informações de commit e data" \
            "true"
        
        nucli_version=$(nu --version 2>/dev/null || echo "versão não disponível")
        register_command_success "nu --version" "$nucli_version"
        print_info "Versão: $nucli_version"
        return 0
    else
        print_error "NuCLI não está instalado"
        register_command_failed "command -v nu" "NuCLI não encontrado no PATH"
        print_info "Para instalar, execute: npm install -g @nubank/nucli"
        return 1
    fi
}

# Verificar configuração do AWS CLI
check_aws_config() {
    print_header "Verificando configuração do AWS"
    
    print_info "Verificando se o AWS CLI está instalado..."
    
    execute_command "command -v aws" \
        "Verifica se o comando 'aws' está instalado e disponível no PATH do sistema" \
        "false"
    
    if [ $? -eq 0 ]; then
        print_success "AWS CLI está instalado"
        register_command_success "command -v aws" "AWS CLI encontrado no PATH"
        
        execute_command "aws --version" \
            "Exibe a versão do AWS CLI instalado, incluindo versão do Python e sistema operacional" \
            "true"
        
        aws_version=$(aws --version 2>/dev/null)
        register_command_success "aws --version" "$aws_version"
        print_info "$aws_version"
        
        print_info "Verificando se as credenciais AWS estão configuradas corretamente..."
        
        execute_command "aws sts get-caller-identity" \
            "Verifica se as credenciais AWS são válidas obtendo informações da identidade do chamador (conta, usuário, ARN)" \
            "false"
        
        if [ $? -eq 0 ]; then
            print_success "Credenciais AWS configuradas corretamente"
            register_command_success "aws sts get-caller-identity" "Credenciais AWS válidas"
            
            execute_command "aws sts get-caller-identity --query Account --output text" \
                "Obtém o número da conta AWS associada às credenciais configuradas" \
                "true"
            
            aws_account=$(aws sts get-caller-identity --query Account --output text 2>/dev/null)
            
            execute_command "aws sts get-caller-identity --query Arn --output text" \
                "Obtém o ARN (Amazon Resource Name) completo do usuário/role autenticado" \
                "true"
            
            aws_user=$(aws sts get-caller-identity --query Arn --output text 2>/dev/null)
            print_info "Conta AWS: $aws_account"
            print_info "Usuário: $aws_user"
        else
            print_error "Credenciais AWS não configuradas ou inválidas"
            register_command_failed "aws sts get-caller-identity" "Credenciais não configuradas ou inválidas"
            print_info "Execute: aws configure"
            return 1
        fi
        
        print_info "Verificando região AWS configurada..."
        
        execute_command "aws configure get region" \
            "Obtém a região AWS padrão configurada nas credenciais" \
            "true"
        
        aws_region=$(aws configure get region 2>/dev/null)
        if [ -n "$aws_region" ]; then
            print_success "Região AWS configurada: $aws_region"
        else
            print_warning "Região AWS não configurada"
            print_info "Execute: aws configure set region <sua-regiao>"
        fi
        
        return 0
    else
        print_error "AWS CLI não está instalado"
        print_info "Para instalar, visite: https://aws.amazon.com/cli/"
        return 1
    fi
}

# Verificar conectividade de rede
check_network_connectivity() {
    print_header "Verificando conectividade de rede"
    
    print_info "Testando conectividade básica de rede..."
    
    execute_command "ping -c 1 8.8.8.8" \
        "Testa conectividade de rede básica fazendo ping para o servidor DNS público do Google (8.8.8.8)" \
        "false"
    
    if [ $? -eq 0 ]; then
        print_success "Conectividade de rede OK"
    else
        print_error "Sem conectividade de rede"
        return 1
    fi
    
    print_info "Verificando resolução DNS..."
    
    execute_command "nslookup aws.amazon.com" \
        "Testa se o DNS está funcionando corretamente resolvendo o domínio aws.amazon.com" \
        "false"
    
    if [ $? -eq 0 ]; then
        print_success "DNS funcionando corretamente"
    else
        print_error "Problemas com DNS"
        return 1
    fi
    
    print_info "Verificando conectividade com serviços AWS..."
    
    execute_command "curl -s --max-time 5 https://aws.amazon.com" \
        "Testa conectividade HTTPS com os serviços AWS usando curl com timeout de 5 segundos" \
        "false"
    
    if [ $? -eq 0 ]; then
        print_success "Conectividade com AWS OK"
    else
        print_warning "Possível problema de conectividade com AWS"
    fi
}

# Verificar variáveis de ambiente
check_environment_variables() {
    print_header "Verificando variáveis de ambiente"
    
    print_info "Verificando variáveis de ambiente AWS..."
    
    # Verificar variáveis AWS comuns
    aws_vars=("AWS_PROFILE" "AWS_REGION" "AWS_DEFAULT_REGION" "AWS_ACCESS_KEY_ID" "AWS_SECRET_ACCESS_KEY")
    
    for var in "${aws_vars[@]}"; do
        if [ -n "${!var}" ]; then
            if [[ "$var" == *"SECRET"* ]] || [[ "$var" == *"KEY"* ]]; then
                print_info "$var está definida (valor oculto)"
                execute_command "echo \"\$$var\" | wc -c" \
                    "Verifica o tamanho da variável $var (sem mostrar o valor por segurança)" \
                    "true"
            else
                execute_command "echo \"\$$var\"" \
                    "Exibe o valor da variável de ambiente $var" \
                    "true"
                print_info "$var=${!var}"
            fi
        fi
    done
    
    print_info "Verificando variáveis de ambiente NuCLI..."
    
    # Verificar variáveis NuCLI
    nucli_vars=("NUCLI_ENV" "NUCLI_PROFILE" "NUCLI_CONFIG_PATH")
    
    for var in "${nucli_vars[@]}"; do
        if [ -n "${!var}" ]; then
            execute_command "echo \"\$$var\"" \
                "Exibe o valor da variável de ambiente $var" \
                "true"
            print_info "$var=${!var}"
        fi
    done
}

# Verificar permissões de arquivos
check_file_permissions() {
    print_header "Verificando permissões de arquivos"
    
    aws_creds_file="$HOME/.aws/credentials"
    
    if [ -f "$aws_creds_file" ]; then
        print_info "Verificando permissões do arquivo de credenciais AWS..."
        
        execute_command "stat -f \"%OLp\" \"$aws_creds_file\" 2>/dev/null || stat -c \"%a\" \"$aws_creds_file\" 2>/dev/null" \
            "Obtém as permissões do arquivo de credenciais AWS em formato octal (ex: 600, 644)" \
            "true"
        
        perms=$(stat -f "%OLp" "$aws_creds_file" 2>/dev/null || stat -c "%a" "$aws_creds_file" 2>/dev/null)
        if [ "$perms" != "600" ] && [ "$perms" != "400" ]; then
            print_warning "Permissões do arquivo de credenciais AWS podem ser inseguras: $perms"
            print_info "Aplicando correção automática..."
            execute_command "chmod 600 \"$aws_creds_file\"" \
                "Corrige as permissões do arquivo para 600 (leitura/escrita apenas para o proprietário, mais seguro)" \
                "false"
            
            if [ $? -eq 0 ]; then
                print_success "Permissões corrigidas automaticamente"
            else
                print_error "Falha ao corrigir permissões"
            fi
        else
            print_success "Permissões do arquivo de credenciais AWS OK"
        fi
    fi
    
    aws_config_file="$HOME/.aws/config"
    
    if [ -f "$aws_config_file" ]; then
        execute_command "test -f \"$aws_config_file\"" \
            "Verifica se o arquivo de configuração AWS existe" \
            "false"
        
        if [ $? -eq 0 ]; then
            print_success "Arquivo de configuração AWS encontrado"
        fi
    fi
}

# Verificar logs de erro recentes
check_recent_errors() {
    print_header "Verificando logs de erro recentes"
    
    if [ -d "/var/log" ]; then
        print_info "Verificando logs do sistema..."
        execute_command "ls -ld /var/log" \
            "Lista informações do diretório de logs do sistema" \
            "true"
        print_info "Logs do sistema em: /var/log"
    fi
    
    if [ -d "$HOME/.nucli" ]; then
        print_info "Verificando diretório NuCLI..."
        
        execute_command "test -d \"$HOME/.nucli\"" \
            "Verifica se o diretório de configuração/logs do NuCLI existe" \
            "false"
        
        if [ $? -eq 0 ]; then
            print_info "Diretório NuCLI encontrado: $HOME/.nucli"
            
            execute_command "find \"$HOME/.nucli\" -name \"*.log\" -type f 2>/dev/null | wc -l" \
                "Conta quantos arquivos de log existem no diretório NuCLI" \
                "true"
            
            log_count=$(find "$HOME/.nucli" -name "*.log" -type f 2>/dev/null | wc -l)
            if [ "$log_count" -gt 0 ]; then
                print_info "Encontrados $log_count arquivo(s) de log"
                
                execute_command "ls -lah \"$HOME/.nucli\"/*.log 2>/dev/null | head -5" \
                    "Lista os arquivos de log do NuCLI com detalhes de tamanho e data" \
                    "true"
                
                print_info "Para visualizar: ls -lah $HOME/.nucli/*.log"
            fi
        fi
    fi
}

# Testar comandos básicos do NuCLI
test_nucli_commands() {
    print_header "Testando comandos básicos do NuCLI"
    
    if ! command -v nu &> /dev/null; then
        print_error "NuCLI não está instalado. Pulando testes."
        return 1
    fi
    
    print_info "Testando comando de ajuda do NuCLI..."
    
    execute_command "nu --help" \
        "Testa o comando de ajuda do NuCLI para verificar se está funcionando corretamente" \
        "false"
    
    if [ $? -eq 0 ]; then
        print_success "Comando 'nu --help' funciona"
    else
        print_error "Comando 'nu --help' falhou"
    fi
    
    print_info "Testando comando de versão do NuCLI..."
    
    execute_command "nu --version" \
        "Testa o comando de versão do NuCLI para verificar se está funcionando corretamente" \
        "true"
    
    if [ $? -eq 0 ]; then
        print_success "Comando 'nu --version' funciona"
    else
        print_warning "Comando 'nu --version' pode não estar disponível"
    fi
}

# Testar comandos básicos do AWS CLI
test_aws_commands() {
    print_header "Testando comandos básicos do AWS CLI"
    
    if ! command -v aws &> /dev/null; then
        print_error "AWS CLI não está instalado. Pulando testes."
        return 1
    fi
    
    print_info "Testando comando de ajuda do AWS CLI..."
    
    execute_command "aws --help" \
        "Testa o comando de ajuda do AWS CLI para verificar se está funcionando corretamente" \
        "false"
    
    if [ $? -eq 0 ]; then
        print_success "Comando 'aws --help' funciona"
    else
        print_error "Comando 'aws --help' falhou"
    fi
    
    print_info "Testando comando de versão do AWS CLI..."
    
    execute_command "aws --version" \
        "Testa o comando de versão do AWS CLI para verificar se está funcionando corretamente" \
        "true"
    
    if [ $? -eq 0 ]; then
        print_success "Comando 'aws --version' funciona"
    else
        print_error "Comando 'aws --version' falhou"
    fi
    
    print_info "Testando autenticação AWS..."
    
    execute_command "aws sts get-caller-identity" \
        "Testa se as credenciais AWS são válidas tentando obter informações da identidade do chamador" \
        "true"
    
    if [ $? -eq 0 ]; then
        print_success "Comando 'aws sts get-caller-identity' funciona"
    else
        print_error "Comando 'aws sts get-caller-identity' falhou"
        print_info "Verifique suas credenciais AWS"
    fi
}

# Verificar roles, escopos e países disponíveis
check_roles_scopes_countries() {
    print_header "Verificando Roles, Escopos e Países Disponíveis"
    
    if ! command -v nu &> /dev/null; then
        print_error "NuCLI não está instalado. Pulando verificação de roles e escopos."
        return 1
    fi
    
    # Verificar se deve tentar executar comandos interativos
    local try_interactive="${TRY_INTERACTIVE:-false}"
    
    print_info "Informações sobre credenciais AWS compartilhadas..."
    
    if [ "$try_interactive" = "true" ]; then
        print_info "Modo interativo automatizado habilitado. Tentando executar comandos..."
        
        # Tentar executar refresh de credenciais com timeout
        execute_interactive_command "nu aws shared-role-credentials refresh -i" \
            "Atualiza as credenciais AWS compartilhadas (tentativa automatizada)" \
            30
        
        if [ $? -eq 0 ]; then
            print_success "Credenciais AWS compartilhadas atualizadas"
        else
            print_warning "Não foi possível atualizar credenciais automaticamente"
            print_info "Execute manualmente: nu aws shared-role-credentials refresh -i"
        fi
    else
        print_warning "AVISO: Comandos de credenciais são interativos e podem travar o script."
        print_info "Por padrão, o script não executa esses comandos automaticamente."
        print_info "Para habilitar execução automatizada, defina: export TRY_INTERACTIVE=true"
        print_success "Comando disponível: nu aws shared-role-credentials"
        print_info ""
        print_info "Para atualizar credenciais manualmente quando necessário, execute:"
        print_info "  nu aws shared-role-credentials refresh -i"
        print_info ""
        print_info "Para acessar o console web AWS:"
        print_info "  nu aws shared-role-credentials web-console -i"
    fi
    
    print_info "Listando países/aliases disponíveis..."
    
    # Lista de países/aliases conhecidos baseado na documentação
    countries=("br" "br-staging" "mx" "ist" "us" "us-staging" "co" "ar")
    
    print_info "Países/Aliases conhecidos disponíveis:"
    for country in "${countries[@]}"; do
        print_info "  - $country"
    done
    
    print_info ""
    print_info "Informações sobre comandos de IAM..."
    
    if [ "$try_interactive" = "true" ]; then
        print_info "Tentando verificar políticas IAM (modo automatizado)..."
        
        # Tentar verificar IAM para alguns países principais
        local main_countries=("br" "co" "mx")
        for country in "${main_countries[@]}"; do
            print_info "Verificando IAM para $country..."
            execute_interactive_command "nu sec shared-role-iam show $(whoami) --target-aws-account=$country" \
                "Obtém informações de IAM para o usuário no país $country" \
                20
        done
    else
        print_warning "AVISO: Comandos de IAM são interativos e podem travar o script."
        print_info "Por padrão, o script não executa esses comandos automaticamente."
        print_info "Para habilitar execução automatizada, defina: export TRY_INTERACTIVE=true"
        print_success "Comando de IAM disponível (nu sec shared-role-iam)"
        print_info ""
        print_info "Para verificar suas políticas IAM em cada país, execute manualmente:"
        for country in "${countries[@]}"; do
            print_info "  nu sec shared-role-iam show $(whoami) --target-aws-account=$country"
        done
        print_info ""
        print_info "Exemplo para Brasil:"
        print_info "  nu sec shared-role-iam show $(whoami) --target-aws-account=br"
    fi
    
    print_info ""
    print_info "Informações sobre comandos de Escopos..."
    
    if [ "$try_interactive" = "true" ]; then
        print_info "Tentando verificar escopos (modo automatizado)..."
        
        # Comandos específicos de escopo por país
        local scope_commands=(
            "nu-br sec scope show $(whoami)"
            "nu-co sec scope show $(whoami)"
            "nu-mx sec scope show $(whoami)"
        )
        
        for cmd in "${scope_commands[@]}"; do
            # Verificar se o comando existe antes de executar
            local cmd_base=$(echo "$cmd" | cut -d' ' -f1)
            if command -v "$cmd_base" &> /dev/null; then
                execute_interactive_command "$cmd" \
                    "Verifica escopos usando $cmd_base" \
                    20
            else
                print_info "Comando $cmd_base não encontrado, tentando formato alternativo..."
                # Tentar formato alternativo: nu sec scope show --target-aws-account
                local country=$(echo "$cmd_base" | sed 's/nu-//')
                execute_interactive_command "nu sec scope show $(whoami) --target-aws-account=$country" \
                    "Verifica escopos para $country usando formato alternativo" \
                    20
            fi
        done
    else
        print_warning "AVISO: Comandos de escopos podem ser interativos e travar o script."
        print_info "Por padrão, o script não executa esses comandos automaticamente."
        print_info "Para habilitar execução automatizada, defina: export TRY_INTERACTIVE=true"
        print_success "Comandos de escopo disponíveis (nu-<pais> sec scope show)"
        print_info ""
        print_info "Para verificar seus escopos em cada país, execute manualmente:"
        
        # Comandos específicos de escopo por país
        scope_commands=(
            "nu-br sec scope show $(whoami)"
            "nu-co sec scope show $(whoami)"
            "nu-mx sec scope show $(whoami)"
        )
        
        for cmd in "${scope_commands[@]}"; do
            print_info "  $cmd"
        done
        
        print_info ""
        print_info "Nota: Se os comandos nu-br, nu-co, nu-mx não estiverem disponíveis,"
        print_info "você pode precisar usar o formato: nu sec scope show <usuario> --target-aws-account=<pais>"
    fi
    
    print_info ""
    print_info "Verificando variável ENG_POLICIES..."
    
    if [ -n "$ENG_POLICIES" ]; then
        print_success "Variável ENG_POLICIES configurada: $ENG_POLICIES"
        execute_command "echo \"\$ENG_POLICIES\"" \
            "Exibe as políticas definidas na variável ENG_POLICIES" \
            "true"
    else
        print_warning "Variável ENG_POLICIES não configurada"
        print_info "Aplicando correção automática..."
        
        # Detectar shell config file
        local shell_config=""
        if [ -n "$ZSH_VERSION" ] || [ -f "$HOME/.zshrc" ]; then
            shell_config="$HOME/.zshrc"
        elif [ -n "$BASH_VERSION" ]; then
            if [ -f "$HOME/.bash_profile" ]; then
                shell_config="$HOME/.bash_profile"
            elif [ -f "$HOME/.bashrc" ]; then
                shell_config="$HOME/.bashrc"
            fi
        fi
        
        if [ -n "$shell_config" ]; then
            # Verificar se já existe ENG_POLICIES no arquivo
            if ! grep -q "ENG_POLICIES" "$shell_config" 2>/dev/null; then
                # Adicionar com valor padrão (pode ser customizado depois)
                local default_policies="casual-dev,prod-eng"
                execute_command "echo '' >> \"$shell_config\" && echo '# ENG_POLICIES - Configure suas políticas AWS aqui' >> \"$shell_config\" && echo \"export ENG_POLICIES=$default_policies\" >> \"$shell_config\"" \
                    "Adiciona configuração de ENG_POLICIES ao arquivo $shell_config com valor padrão" \
                    "false"
                
                if [ $? -eq 0 ]; then
                    print_success "Variável ENG_POLICIES configurada automaticamente em $shell_config"
                    print_info "Valor padrão: $default_policies"
                    print_info "Para personalizar, edite: $shell_config"
                    print_info "Para aplicar agora: source $shell_config"
                    
                    # Tentar carregar no shell atual
                    export ENG_POLICIES="$default_policies"
                    print_success "ENG_POLICIES carregada na sessão atual: $ENG_POLICIES"
                else
                    print_error "Falha ao configurar ENG_POLICIES automaticamente"
                    print_info "Configure manualmente: echo 'export ENG_POLICIES=<policy-names>' >> $shell_config"
                fi
            else
                print_info "ENG_POLICIES já existe em $shell_config mas não está carregada"
                print_info "Para carregar: source $shell_config"
            fi
        else
            print_warning "Não foi possível detectar arquivo de configuração do shell"
            print_info "Configure manualmente:"
            print_info "  echo 'export ENG_POLICIES=casual-dev,prod-eng' >> ~/.zshrc"
            print_info "  source ~/.zshrc"
        fi
    fi
    
    print_info "Verificando aliases configurados..."
    
    # Verificar aliases comuns
    if alias | grep -q "aws-br"; then
        print_success "Aliases AWS encontrados"
        execute_command "alias | grep aws-br" \
            "Lista aliases AWS configurados" \
            "true"
    else
        print_info "Nenhum alias AWS encontrado"
        print_info "Para criar alias: alias aws-br-refresh=\"nu aws shared-role-credentials refresh --account-alias br --keep-policies=\$ENG_POLICIES\""
    fi
}

# Diagnóstico de problemas comuns e correção automática
diagnose_common_issues() {
    print_header "Diagnóstico de Problemas Comuns e Correção Automática"
    
    issues_found=0
    issues_fixed=0
    
    print_info "Verificando problemas conhecidos..."
    
    # Verificar NuCLI
    execute_command "command -v nu" \
        "Verifica se o NuCLI está instalado (problema comum: comando não encontrado)" \
        "false"
    
    if [ $? -ne 0 ]; then
        print_error "Problema: NuCLI não instalado"
        print_warning "Correção automática não disponível para instalação do NuCLI"
        print_info "Solução manual: npm install -g @nubank/nucli"
        ((issues_found++))
    fi
    
    # Verificar AWS CLI
    execute_command "command -v aws" \
        "Verifica se o AWS CLI está instalado (problema comum: comando não encontrado)" \
        "false"
    
    if [ $? -ne 0 ]; then
        print_error "Problema: AWS CLI não instalado"
        print_warning "Correção automática não disponível para instalação do AWS CLI"
        print_info "Solução manual: Instale o AWS CLI conforme documentação oficial"
        ((issues_found++))
    fi
    
    # Verificar credenciais AWS
    execute_command "aws sts get-caller-identity" \
        "Verifica se as credenciais AWS são válidas (problema comum: credenciais inválidas)" \
        "false"
    
    if [ $? -ne 0 ]; then
        print_error "Problema: Credenciais AWS inválidas ou não configuradas"
        print_warning "Correção automática não disponível para configuração de credenciais"
        print_info "Solução manual: Execute 'aws configure' para configurar credenciais"
        ((issues_found++))
    fi
    
    # Verificar permissões de arquivos AWS
    aws_creds_file="$HOME/.aws/credentials"
    if [ -f "$aws_creds_file" ]; then
        perms=$(stat -f "%OLp" "$aws_creds_file" 2>/dev/null || stat -c "%a" "$aws_creds_file" 2>/dev/null)
        if [ "$perms" != "600" ] && [ "$perms" != "400" ]; then
            print_warning "Problema: Permissões inseguras no arquivo de credenciais AWS: $perms"
            print_info "Aplicando correção automática..."
            
            execute_command "chmod 600 \"$aws_creds_file\"" \
                "Corrige as permissões do arquivo de credenciais AWS para 600 (mais seguro)" \
                "false"
            
            if [ $? -eq 0 ]; then
                print_success "Permissões corrigidas automaticamente"
                ((issues_fixed++))
            else
                print_error "Falha ao corrigir permissões"
                ((issues_found++))
            fi
        fi
    fi
    
    # Verificar região AWS
    if command -v aws &> /dev/null; then
        aws_region=$(aws configure get region 2>/dev/null)
        if [ -z "$aws_region" ]; then
            print_warning "Problema: Região AWS não configurada"
            print_info "Sugestão: Configure uma região padrão com 'aws configure set region <sua-regiao>'"
            print_info "Regiões comuns: us-east-1, us-west-2, sa-east-1"
            ((issues_found++))
        fi
    fi
    
    # Resumo
    echo ""
    if [ $issues_found -eq 0 ]; then
        print_success "Nenhum problema comum detectado"
    else
        print_warning "Foram encontrados $issues_found problema(s)"
        if [ $issues_fixed -gt 0 ]; then
            print_success "$issues_fixed problema(s) corrigido(s) automaticamente"
        fi
    fi
}

# Função auxiliar para escrever linha colorida (para terminal) e sem cor (para arquivo)
write_report_line() {
    local color="$1"
    local text="$2"
    local file="$3"
    
    # Escrever versão sem cor no arquivo (texto limpo)
    echo "$text" >> "$file"
    # Escrever versão colorida no terminal
    echo -e "${color}${text}${NC}"
}

# Gerar relatório final consolidado após diagnóstico completo
generate_final_report() {
    print_header "Gerando Relatório Final de Diagnóstico"
    
    local report_file="nucli-diagnostico-final-$(date +%Y%m%d-%H%M%S).txt"
    
    print_info "Coletando informações do sistema..."
    
    # Criar arquivo vazio primeiro
    > "$report_file"
    
    # Função para escrever seção colorida
    write_section() {
        local title="$1"
        write_report_line "$CYAN" "======================================================================" "$report_file"
        write_report_line "$CYAN" "$title" "$report_file"
        write_report_line "$CYAN" "======================================================================" "$report_file"
        write_report_line "$NC" "" "$report_file"
    }
    
    # Cabeçalho
    write_report_line "$BLUE" "======================================================================" "$report_file"
    write_report_line "$BLUE" "RELATÓRIO FINAL DE DIAGNÓSTICO - NuCLI e AWS" "$report_file"
    write_report_line "$BLUE" "======================================================================" "$report_file"
    write_report_line "$NC" "Gerado em: $(date '+%Y-%m-%d %H:%M:%S')" "$report_file"
    write_report_line "$NC" "Sistema: $(uname -s) $(uname -r)" "$report_file"
    write_report_line "$NC" "Hostname: $(hostname)" "$report_file"
    write_report_line "$NC" "Usuário: $(whoami)" "$report_file"
    write_report_line "$NC" "" "$report_file"
    
    # 1. STATUS DE INSTALAÇÃO
    write_section "1. STATUS DE INSTALAÇÃO"
    
    # NuCLI
    write_report_line "$NC" "NuCLI:" "$report_file"
    if command -v nu &> /dev/null; then
        local nu_version=$(nu --version 2>/dev/null | head -1 || echo "N/A")
        write_report_line "$GREEN" "  [✓] Instalado" "$report_file"
        write_report_line "$NC" "  Versão: $nu_version" "$report_file"
    else
        write_report_line "$RED" "  [✗] NÃO INSTALADO" "$report_file"
        write_report_line "$YELLOW" "  Ação necessária: npm install -g @nubank/nucli" "$report_file"
    fi
    write_report_line "$NC" "" "$report_file"
    
    # AWS CLI
    write_report_line "$NC" "AWS CLI:" "$report_file"
    if command -v aws &> /dev/null; then
        local aws_version=$(aws --version 2>/dev/null || echo "N/A")
        write_report_line "$GREEN" "  [✓] Instalado" "$report_file"
        write_report_line "$NC" "  Versão: $aws_version" "$report_file"
    else
        write_report_line "$RED" "  [✗] NÃO INSTALADO" "$report_file"
        write_report_line "$YELLOW" "  Ação necessária: Instalar AWS CLI" "$report_file"
    fi
    write_report_line "$NC" "" "$report_file"
    
    # 2. CONFIGURAÇÕES AWS
    write_section "2. CONFIGURAÇÕES AWS"
    
    if command -v aws &> /dev/null; then
        if aws sts get-caller-identity &> /dev/null; then
            local aws_account=$(aws sts get-caller-identity --query Account --output text 2>/dev/null || echo "N/A")
            local aws_arn=$(aws sts get-caller-identity --query Arn --output text 2>/dev/null || echo "N/A")
            write_report_line "$GREEN" "Credenciais AWS: [✓] Configuradas e válidas" "$report_file"
            write_report_line "$NC" "  Conta: $aws_account" "$report_file"
            write_report_line "$NC" "  ARN: $aws_arn" "$report_file"
        else
            write_report_line "$RED" "Credenciais AWS: [✗] Não configuradas ou inválidas" "$report_file"
            write_report_line "$YELLOW" "  Ação necessária: aws configure" "$report_file"
        fi
        
        local aws_region=$(aws configure get region 2>/dev/null)
        if [ -n "$aws_region" ]; then
            write_report_line "$GREEN" "Região AWS: [✓] $aws_region" "$report_file"
        else
            write_report_line "$RED" "Região AWS: [✗] Não configurada" "$report_file"
            write_report_line "$YELLOW" "  Ação necessária: aws configure set region <sua-regiao>" "$report_file"
        fi
    fi
    write_report_line "$NC" "" "$report_file"
    
    # 3. VARIÁVEIS DE AMBIENTE
    write_section "3. VARIÁVEIS DE AMBIENTE"
    
    if [ -n "$ENG_POLICIES" ]; then
        write_report_line "$GREEN" "ENG_POLICIES: [✓] Configurada" "$report_file"
        write_report_line "$NC" "  Valor: $ENG_POLICIES" "$report_file"
    else
        write_report_line "$RED" "ENG_POLICIES: [✗] NÃO CONFIGURADA" "$report_file"
        write_report_line "$YELLOW" "  Ação necessária: export ENG_POLICIES=<policy-names>" "$report_file"
        write_report_line "$YELLOW" "  Exemplo: export ENG_POLICIES=casual-dev,prod-eng" "$report_file"
    fi
    write_report_line "$NC" "" "$report_file"
    
    # 4. PAÍSES/ALIASES DISPONÍVEIS
    write_section "4. PAÍSES/ALIASES DISPONÍVEIS"
    
    local countries=("br" "br-staging" "mx" "ist" "us" "us-staging" "co" "ar")
    for country in "${countries[@]}"; do
        write_report_line "$BLUE" "  - $country" "$report_file"
    done
    write_report_line "$NC" "" "$report_file"
    
    # 5. PERMISSÕES DE ARQUIVOS
    write_section "5. PERMISSÕES DE ARQUIVOS"
    
    local aws_creds_file="$HOME/.aws/credentials"
    if [ -f "$aws_creds_file" ]; then
        local perms=$(stat -f "%OLp" "$aws_creds_file" 2>/dev/null || stat -c "%a" "$aws_creds_file" 2>/dev/null)
        if [ "$perms" = "600" ] || [ "$perms" = "400" ]; then
            write_report_line "$GREEN" "Arquivo de credenciais AWS: [✓] Permissões seguras ($perms)" "$report_file"
        else
            write_report_line "$YELLOW" "Arquivo de credenciais AWS: [⚠] Permissões inseguras ($perms)" "$report_file"
            write_report_line "$YELLOW" "  Ação necessária: chmod 600 $aws_creds_file" "$report_file"
        fi
    else
        write_report_line "$RED" "Arquivo de credenciais AWS: [✗] Não encontrado" "$report_file"
    fi
    write_report_line "$NC" "" "$report_file"
    
    # 6. CONECTIVIDADE
    write_section "6. CONECTIVIDADE"
    
    if ping -c 1 8.8.8.8 &> /dev/null; then
        write_report_line "$GREEN" "Rede: [✓] Conectividade OK" "$report_file"
    else
        write_report_line "$RED" "Rede: [✗] Problemas de conectividade detectados" "$report_file"
    fi
    write_report_line "$NC" "" "$report_file"
    
    # 7. EXECUÇÃO DE COMANDOS E RESULTADOS
    write_section "7. EXECUÇÃO DE COMANDOS E RESULTADOS"
    
    if ! command -v nu &> /dev/null; then
        write_report_line "$YELLOW" "NuCLI não está instalado. Pulando execução de comandos." "$report_file"
    else
        local try_interactive="${TRY_INTERACTIVE:-false}"
        
        # Configurar comando timeout
        local timeout_cmd=""
        if command -v timeout &> /dev/null; then
            timeout_cmd="timeout"
        elif command -v gtimeout &> /dev/null; then
            timeout_cmd="gtimeout"
        fi
        
        # 1. Atualizar NuCLI (sempre tenta executar, não é interativo)
        write_report_line "$NC" "Verificando atualização do NuCLI:" "$report_file"
        write_report_line "$BLUE" "  Comando: nu update" "$report_file"
        
        local update_output=""
        local update_exit=1
        if [ -n "$timeout_cmd" ]; then
            update_output=$($timeout_cmd 30 nu update 2>&1)
            update_exit=$?
        else
            update_output=$(nu update 2>&1)
            update_exit=$?
        fi
        
        if [ $update_exit -eq 0 ]; then
            write_report_line "$GREEN" "  [✓] Comando executado com sucesso" "$report_file"
            register_command_success "nu update" "$(echo "$update_output" | head -3 | tr '\n' '; ')"
            if [ -n "$update_output" ]; then
                write_report_line "$NC" "  Saída (primeiras linhas):" "$report_file"
                echo "$update_output" | head -10 | while IFS= read -r line; do
                    write_report_line "$NC" "    $line" "$report_file"
                done
            fi
        elif [ $update_exit -eq 124 ]; then
            write_report_line "$YELLOW" "  [⚠] Comando atingiu timeout" "$report_file"
            register_command_needs_action "nu update" "Timeout - pode precisar de mais tempo ou interação"
        else
            write_report_line "$YELLOW" "  [⚠] Comando retornou código: $update_exit" "$report_file"
            register_command_failed "nu update" "Código de saída: $update_exit"
            if [ -n "$update_output" ]; then
                write_report_line "$NC" "  Saída:" "$report_file"
                echo "$update_output" | head -5 | while IFS= read -r line; do
                    write_report_line "$NC" "    $line" "$report_file"
                done
            fi
        fi
        write_report_line "$NC" "" "$report_file"
        
        # 2. Ver Escopos
        write_report_line "$NC" "Verificando Escopos:" "$report_file"
        local scope_countries=("br" "co" "mx")
        local scope_found=false
        
        for country in "${scope_countries[@]}"; do
            write_report_line "$BLUE" "  Escopos para $country:" "$report_file"
            
            # Tentar comando nu-<pais> primeiro
            local scope_cmd="nu-$country sec scope show $(whoami)"
            local scope_output=""
            local scope_exit=1
            
            if command -v "nu-$country" &> /dev/null; then
                if [ -n "$timeout_cmd" ]; then
                    scope_output=$($timeout_cmd 20 bash -c "$scope_cmd" 2>&1)
                    scope_exit=$?
                else
                    scope_output=$(bash -c "$scope_cmd" 2>&1)
                    scope_exit=$?
                fi
            else
                # Tentar formato alternativo
                local alt_cmd="nu sec scope show $(whoami) --target-aws-account=$country"
                if [ -n "$timeout_cmd" ]; then
                    scope_output=$($timeout_cmd 20 bash -c "$alt_cmd" 2>&1)
                    scope_exit=$?
                else
                    scope_output=$(bash -c "$alt_cmd" 2>&1)
                    scope_exit=$?
                fi
            fi
            
            if [ $scope_exit -eq 0 ] && [ -n "$scope_output" ] && ! echo "$scope_output" | grep -qi "error\|failed\|timeout"; then
                write_report_line "$GREEN" "  [✓] Escopos encontrados para $country" "$report_file"
                register_command_success "nu-$country sec scope show $(whoami)" "$(echo "$scope_output" | head -2 | tr '\n' '; ')"
                write_report_line "$NC" "  Resultado:" "$report_file"
                echo "$scope_output" | head -30 | while IFS= read -r line; do
                    write_report_line "$NC" "    $line" "$report_file"
                done
                scope_found=true
            elif [ $scope_exit -eq 124 ]; then
                write_report_line "$YELLOW" "  [⚠] Comando atingiu timeout para $country" "$report_file"
                register_command_needs_action "nu-$country sec scope show $(whoami)" "Timeout - pode precisar de autenticação interativa"
            else
                write_report_line "$YELLOW" "  [⚠] Não foi possível obter escopos para $country (código: $scope_exit)" "$report_file"
                register_command_failed "nu-$country sec scope show $(whoami)" "Código: $scope_exit - pode requerer autenticação"
            fi
            write_report_line "$NC" "" "$report_file"
        done
        
        if [ "$scope_found" = "false" ]; then
            write_report_line "$YELLOW" "  Nenhum escopo foi encontrado ou comandos requerem autenticação interativa" "$report_file"
            write_report_line "$NC" "  Execute manualmente:" "$report_file"
            for country in "${scope_countries[@]}"; do
                write_report_line "$BLUE" "    nu-$country sec scope show $(whoami)" "$report_file"
            done
        fi
        write_report_line "$NC" "" "$report_file"
        
        # 3. Ver Políticas IAM do usuário atual
        write_report_line "$NC" "Verificando Políticas IAM do usuário atual:" "$report_file"
        local current_user=$(whoami)
        write_report_line "$BLUE" "  Usuário: $current_user" "$report_file"
        
        # Tentar obter políticas IAM para o país principal (br) como exemplo
        local iam_cmd="nu sec shared-role-iam show $current_user --target-aws-account=br"
        local iam_output=""
        local iam_exit=1
        local iam_found=false
        
        if [ "$try_interactive" = "true" ]; then
            write_report_line "$BLUE" "  Comando: $iam_cmd" "$report_file"
            
            if [ -n "$timeout_cmd" ]; then
                iam_output=$($timeout_cmd 20 bash -c "$iam_cmd" 2>&1)
                iam_exit=$?
            else
                iam_output=$(bash -c "$iam_cmd" 2>&1)
                iam_exit=$?
            fi
            
            # Verificar se o comando foi bem-sucedido e tem conteúdo válido
            if [ $iam_exit -eq 0 ]; then
                # Verificar se a saída contém informações válidas (não apenas mensagens de erro)
                if [ -n "$iam_output" ] && ! echo "$iam_output" | grep -qiE "error|Error|ERROR|failed|Failed|not found|não encontrado|timeout|permission denied"; then
                    # Verificar se há conteúdo real (mais que apenas espaços/linhas vazias)
                    local content_lines=$(echo "$iam_output" | grep -v '^[[:space:]]*$' | wc -l | tr -d ' ')
                    if [ "$content_lines" -gt 0 ]; then
                        write_report_line "$GREEN" "  [✓] Políticas IAM encontradas" "$report_file"
                        register_command_success "$iam_cmd" "$(echo "$iam_output" | head -3 | tr '\n' '; ')"
                        write_report_line "$NC" "  Resultado:" "$report_file"
                        echo "$iam_output" | head -50 | while IFS= read -r line; do
                            write_report_line "$NC" "    $line" "$report_file"
                        done
                        iam_found=true
                        
                        # Perguntar se deseja executar para outros países
                        echo ""
                        if [ -t 0 ]; then  # Verificar se está em modo interativo
                            write_report_line "$NC" "" "$report_file"
                            write_report_line "$YELLOW" "  [ℹ] Comando funcionou para 'br'. Deseja executar para outros países?" "$report_file"
                            echo ""
                            print_info "Países disponíveis: br, co, mx, br-staging, ist, etc."
                            echo ""
                            echo "1. Sim, executar para todos os países principais (co, mx)"
                            echo "2. Sim, executar para todos os países disponíveis"
                            echo "3. Não, apenas mostrar os comandos"
                            echo "4. Executar países individualmente"
                            echo ""
                            read -p "Escolha uma opção (1-4): " countries_option
                            
                            case $countries_option in
                                1)
                                    echo ""
                                    print_info "Executando para países principais: co, mx"
                                    echo ""
                                    local main_countries=("co" "mx")
                                    for country in "${main_countries[@]}"; do
                                        local country_cmd="nu sec shared-role-iam show $current_user --target-aws-account=$country"
                                        echo ""
                                        write_report_line "$BLUE" "  Executando para $country:" "$report_file"
                                        print_info "Comando: $country_cmd"
                                        
                                        local country_output=""
                                        local country_exit=1
                                        if [ -n "$timeout_cmd" ]; then
                                            country_output=$($timeout_cmd 20 bash -c "$country_cmd" 2>&1)
                                            country_exit=$?
                                        else
                                            country_output=$(bash -c "$country_cmd" 2>&1)
                                            country_exit=$?
                                        fi
                                        
                                        if [ $country_exit -eq 0 ] && [ -n "$country_output" ] && ! echo "$country_output" | grep -qiE "error|Error|ERROR|failed|Failed|not found|não encontrado|timeout|permission denied"; then
                                            local country_content_lines=$(echo "$country_output" | grep -v '^[[:space:]]*$' | wc -l | tr -d ' ')
                                            if [ "$country_content_lines" -gt 0 ]; then
                                                write_report_line "$GREEN" "  [✓] Políticas IAM encontradas para $country" "$report_file"
                                                register_command_success "$country_cmd" "$(echo "$country_output" | head -3 | tr '\n' '; ')"
                                                write_report_line "$NC" "  Resultado:" "$report_file"
                                                echo "$country_output" | head -30 | while IFS= read -r line; do
                                                    write_report_line "$NC" "    $line" "$report_file"
                                                done
                                            else
                                                write_report_line "$YELLOW" "  [⚠] Nenhuma política encontrada para $country" "$report_file"
                                                register_command_needs_action "$country_cmd" "Nenhuma política encontrada"
                                            fi
                                        else
                                            write_report_line "$YELLOW" "  [⚠] Não foi possível obter políticas para $country" "$report_file"
                                            register_command_needs_action "$country_cmd" "Pode requerer autenticação interativa"
                                        fi
                                    done
                                    ;;
                                2)
                                    echo ""
                                    print_info "Executando para todos os países disponíveis..."
                                    echo ""
                                    local all_countries=("co" "mx" "br-staging" "ist")
                                    for country in "${all_countries[@]}"; do
                                        local country_cmd="nu sec shared-role-iam show $current_user --target-aws-account=$country"
                                        echo ""
                                        write_report_line "$BLUE" "  Executando para $country:" "$report_file"
                                        print_info "Comando: $country_cmd"
                                        
                                        local country_output=""
                                        local country_exit=1
                                        if [ -n "$timeout_cmd" ]; then
                                            country_output=$($timeout_cmd 20 bash -c "$country_cmd" 2>&1)
                                            country_exit=$?
                                        else
                                            country_output=$(bash -c "$country_cmd" 2>&1)
                                            country_exit=$?
                                        fi
                                        
                                        if [ $country_exit -eq 0 ] && [ -n "$country_output" ] && ! echo "$country_output" | grep -qiE "error|Error|ERROR|failed|Failed|not found|não encontrado|timeout|permission denied"; then
                                            local country_content_lines=$(echo "$country_output" | grep -v '^[[:space:]]*$' | wc -l | tr -d ' ')
                                            if [ "$country_content_lines" -gt 0 ]; then
                                                write_report_line "$GREEN" "  [✓] Políticas IAM encontradas para $country" "$report_file"
                                                register_command_success "$country_cmd" "$(echo "$country_output" | head -3 | tr '\n' '; ')"
                                                write_report_line "$NC" "  Resultado:" "$report_file"
                                                echo "$country_output" | head -30 | while IFS= read -r line; do
                                                    write_report_line "$NC" "    $line" "$report_file"
                                                done
                                            else
                                                write_report_line "$YELLOW" "  [⚠] Nenhuma política encontrada para $country" "$report_file"
                                                register_command_needs_action "$country_cmd" "Nenhuma política encontrada"
                                            fi
                                        else
                                            write_report_line "$YELLOW" "  [⚠] Não foi possível obter políticas para $country" "$report_file"
                                            register_command_needs_action "$country_cmd" "Pode requerer autenticação interativa"
                                        fi
                                    done
                                    ;;
                                4)
                                    echo ""
                                    print_info "Executando países individualmente..."
                                    echo ""
                                    local available_countries=("co" "mx" "br-staging" "ist")
                                    for country in "${available_countries[@]}"; do
                                        local country_cmd="nu sec shared-role-iam show $current_user --target-aws-account=$country"
                                        echo ""
                                        print_info "Deseja executar para $country?"
                                        read -p "Executar para $country? (s/N): " exec_country
                                        if [[ "$exec_country" =~ ^[SsYy]$ ]]; then
                                            write_report_line "$BLUE" "  Executando para $country:" "$report_file"
                                            print_info "Comando: $country_cmd"
                                            
                                            local country_output=""
                                            local country_exit=1
                                            if [ -n "$timeout_cmd" ]; then
                                                country_output=$($timeout_cmd 20 bash -c "$country_cmd" 2>&1)
                                                country_exit=$?
                                            else
                                                country_output=$(bash -c "$country_cmd" 2>&1)
                                                country_exit=$?
                                            fi
                                            
                                            if [ $country_exit -eq 0 ] && [ -n "$country_output" ] && ! echo "$country_output" | grep -qiE "error|Error|ERROR|failed|Failed|not found|não encontrado|timeout|permission denied"; then
                                                local country_content_lines=$(echo "$country_output" | grep -v '^[[:space:]]*$' | wc -l | tr -d ' ')
                                                if [ "$country_content_lines" -gt 0 ]; then
                                                    write_report_line "$GREEN" "  [✓] Políticas IAM encontradas para $country" "$report_file"
                                                    register_command_success "$country_cmd" "$(echo "$country_output" | head -3 | tr '\n' '; ')"
                                                    write_report_line "$NC" "  Resultado:" "$report_file"
                                                    echo "$country_output" | head -30 | while IFS= read -r line; do
                                                        write_report_line "$NC" "    $line" "$report_file"
                                                    done
                                                else
                                                    write_report_line "$YELLOW" "  [⚠] Nenhuma política encontrada para $country" "$report_file"
                                                    register_command_needs_action "$country_cmd" "Nenhuma política encontrada"
                                                fi
                                            else
                                                write_report_line "$YELLOW" "  [⚠] Não foi possível obter políticas para $country" "$report_file"
                                                register_command_needs_action "$country_cmd" "Pode requerer autenticação interativa"
                                            fi
                                        else
                                            print_info "Pulando país: $country"
                                        fi
                                    done
                                    ;;
                                *)
                                    write_report_line "$NC" "  Comandos para outros países:" "$report_file"
                                    write_report_line "$BLUE" "    nu sec shared-role-iam show $current_user --target-aws-account=co" "$report_file"
                                    write_report_line "$BLUE" "    nu sec shared-role-iam show $current_user --target-aws-account=mx" "$report_file"
                                    write_report_line "$BLUE" "    nu sec shared-role-iam show $current_user --target-aws-account=br-staging" "$report_file"
                                    write_report_line "$BLUE" "    nu sec shared-role-iam show $current_user --target-aws-account=ist" "$report_file"
                                    ;;
                            esac
                        else
                            write_report_line "$NC" "" "$report_file"
                            write_report_line "$NC" "  Para verificar políticas em outros países, execute:" "$report_file"
                            write_report_line "$BLUE" "    nu sec shared-role-iam show $current_user --target-aws-account=co" "$report_file"
                            write_report_line "$BLUE" "    nu sec shared-role-iam show $current_user --target-aws-account=mx" "$report_file"
                        fi
                    else
                        write_report_line "$YELLOW" "  [⚠] Comando executado mas nenhuma política encontrada" "$report_file"
                        register_command_needs_action "$iam_cmd" "Nenhuma política encontrada ou usuário sem permissões"
                        if [ -n "$iam_output" ]; then
                            write_report_line "$NC" "  Saída: $iam_output" "$report_file"
                        fi
                    fi
                else
                    write_report_line "$YELLOW" "  [⚠] Comando executado mas pode ter falhado ou requer autenticação" "$report_file"
                    register_command_needs_action "$iam_cmd" "Pode requerer autenticação interativa"
                    if [ -n "$iam_output" ]; then
                        write_report_line "$NC" "  Saída (primeiras linhas):" "$report_file"
                        echo "$iam_output" | head -5 | while IFS= read -r line; do
                            write_report_line "$NC" "    $line" "$report_file"
                        done
                    fi
                fi
            elif [ $iam_exit -eq 124 ]; then
                write_report_line "$YELLOW" "  [⚠] Comando atingiu timeout" "$report_file"
                register_command_needs_action "$iam_cmd" "Timeout - requer mais tempo ou autenticação"
            else
                write_report_line "$YELLOW" "  [⚠] Comando falhou (código: $iam_exit)" "$report_file"
                register_command_failed "$iam_cmd" "Código: $iam_exit"
                if [ -n "$iam_output" ]; then
                    write_report_line "$NC" "  Saída:" "$report_file"
                    echo "$iam_output" | head -5 | while IFS= read -r line; do
                        write_report_line "$NC" "    $line" "$report_file"
                    done
                fi
            fi
        else
            write_report_line "$YELLOW" "  [⚠] Modo interativo desabilitado" "$report_file"
            write_report_line "$NC" "  Para verificar políticas IAM, execute manualmente:" "$report_file"
            write_report_line "$BLUE" "    nu sec shared-role-iam show $current_user --target-aws-account=<pais>" "$report_file"
            write_report_line "$NC" "  Ou habilite: export TRY_INTERACTIVE=true" "$report_file"
        fi
        
        if [ "$iam_found" = "false" ] && [ "$try_interactive" = "true" ]; then
            write_report_line "$NC" "" "$report_file"
            write_report_line "$NC" "  Para verificar políticas em outros países, execute:" "$report_file"
            write_report_line "$BLUE" "    nu sec shared-role-iam show $current_user --target-aws-account=co" "$report_file"
            write_report_line "$BLUE" "    nu sec shared-role-iam show $current_user --target-aws-account=mx" "$report_file"
        fi
        write_report_line "$NC" "" "$report_file"
        
        # 4. Refresh Credenciais AWS (interativo)
        write_report_line "$NC" "Refresh Credenciais AWS:" "$report_file"
        write_report_line "$BLUE" "  Comando: nu aws shared-role-credentials refresh -i" "$report_file"
        
        if [ -t 0 ]; then  # Verificar se está em modo interativo
            write_report_line "$YELLOW" "  [ℹ] Este comando requer interação do usuário" "$report_file"
            write_report_line "$NC" "  Deseja executar agora? (s/N): " "$report_file"
            # Não podemos usar read aqui porque estamos escrevendo no arquivo
            # Vamos registrar como precisa de ação e oferecer execução no relatório consolidado
            register_command_needs_action "nu aws shared-role-credentials refresh -i" "Requer interação manual do usuário"
        else
            write_report_line "$YELLOW" "  [ℹ] Modo não-interativo: Execute manualmente quando necessário" "$report_file"
            register_command_needs_action "nu aws shared-role-credentials refresh -i" "Requer interação manual do usuário"
        fi
        write_report_line "$NC" "" "$report_file"
    fi
    
    # 8. RESUMO E AÇÕES RECOMENDADAS
    write_section "8. RESUMO E AÇÕES RECOMENDADAS"
    
    local issues_count=0
    local fixes_applied=0
    
    if ! command -v nu &> /dev/null; then
        write_report_line "$RED" "[✗] Instalar NuCLI" "$report_file"
        ((issues_count++))
    fi
    
    if ! command -v aws &> /dev/null; then
        write_report_line "$RED" "[✗] Instalar AWS CLI" "$report_file"
        ((issues_count++))
    fi
    
    if command -v aws &> /dev/null && ! aws sts get-caller-identity &> /dev/null; then
        write_report_line "$RED" "[✗] Configurar credenciais AWS" "$report_file"
        ((issues_count++))
    fi
    
    if [ -z "$ENG_POLICIES" ]; then
        write_report_line "$RED" "[✗] Configurar ENG_POLICIES" "$report_file"
        ((issues_count++))
    else
        write_report_line "$GREEN" "[✓] ENG_POLICIES configurada" "$report_file"
        ((fixes_applied++))
    fi
    
    if [ -f "$aws_creds_file" ]; then
        local perms=$(stat -f "%OLp" "$aws_creds_file" 2>/dev/null || stat -c "%a" "$aws_creds_file" 2>/dev/null)
        if [ "$perms" != "600" ] && [ "$perms" != "400" ]; then
            write_report_line "$YELLOW" "[⚠] Corrigir permissões do arquivo de credenciais" "$report_file"
            ((issues_count++))
        else
            write_report_line "$GREEN" "[✓] Permissões de arquivo OK" "$report_file"
            ((fixes_applied++))
        fi
    fi
    
    write_report_line "$NC" "" "$report_file"
    write_report_line "$NC" "Total de problemas encontrados: $issues_count" "$report_file"
    write_report_line "$NC" "Total de correções aplicadas: $fixes_applied" "$report_file"
    write_report_line "$NC" "" "$report_file"
    
    if [ $issues_count -eq 0 ]; then
        write_report_line "$GREEN" "STATUS GERAL: [✓] Tudo configurado corretamente!" "$report_file"
    else
        write_report_line "$YELLOW" "STATUS GERAL: [⚠] $issues_count problema(s) encontrado(s)" "$report_file"
    fi
    
    write_report_line "$NC" "" "$report_file"
    write_report_line "$BLUE" "======================================================================" "$report_file"
    write_report_line "$BLUE" "FIM DO RELATÓRIO" "$report_file"
    write_report_line "$BLUE" "======================================================================" "$report_file"
    
    execute_command "test -f \"$report_file\"" \
        "Verifica se o arquivo de relatório final foi criado com sucesso" \
        "false"
    
    print_success "Relatório final salvo em: $report_file"
    print_info "Para visualizar: cat $report_file"
    echo ""
    print_info "Relatório já foi exibido acima com cores para facilitar a leitura."
    
    # Gerar relatório consolidado de comandos executados
    generate_consolidated_command_report
}

# Gerar relatório consolidado de todos os comandos executados
generate_consolidated_command_report() {
    print_header "Relatório Consolidado de Comandos Executados"
    
    local consolidated_file="nucli-comandos-executados-$(date +%Y%m%d-%H%M%S).txt"
    > "$consolidated_file"
    
    write_report_line "$BLUE" "======================================================================" "$consolidated_file"
    write_report_line "$BLUE" "RELATÓRIO CONSOLIDADO DE COMANDOS EXECUTADOS" "$consolidated_file"
    write_report_line "$BLUE" "======================================================================" "$consolidated_file"
    write_report_line "$NC" "Gerado em: $(date '+%Y-%m-%d %H:%M:%S')" "$consolidated_file"
    write_report_line "$NC" "" "$consolidated_file"
    
    # Comandos que funcionaram (VERDE)
    if [ ${#COMMAND_SUCCESS[@]} -gt 0 ]; then
        write_report_line "$GREEN" "======================================================================" "$consolidated_file"
        write_report_line "$GREEN" "✓ COMANDOS EXECUTADOS COM SUCESSO (${#COMMAND_SUCCESS[@]})" "$consolidated_file"
        write_report_line "$GREEN" "======================================================================" "$consolidated_file"
        write_report_line "$NC" "" "$consolidated_file"
        
        for item in "${COMMAND_SUCCESS[@]}"; do
            local cmd=$(echo "$item" | cut -d'|' -f1)
            local output=$(echo "$item" | cut -d'|' -f2-)
            write_report_line "$GREEN" "[✓] $cmd" "$consolidated_file"
            if [ -n "$output" ] && [ "$output" != "null" ]; then
                write_report_line "$NC" "   Saída: $(echo "$output" | head -3 | tr '\n' ' ')" "$consolidated_file"
            fi
            write_report_line "$NC" "" "$consolidated_file"
        done
    else
        write_report_line "$YELLOW" "Nenhum comando executado com sucesso registrado" "$consolidated_file"
        write_report_line "$NC" "" "$consolidated_file"
    fi
    
    # Comandos que falharam (VERMELHO)
    if [ ${#COMMAND_FAILED[@]} -gt 0 ]; then
        write_report_line "$RED" "======================================================================" "$consolidated_file"
        write_report_line "$RED" "✗ COMANDOS QUE FALHARAM (${#COMMAND_FAILED[@]})" "$consolidated_file"
        write_report_line "$RED" "======================================================================" "$consolidated_file"
        write_report_line "$NC" "" "$consolidated_file"
        
        for item in "${COMMAND_FAILED[@]}"; do
            local cmd=$(echo "$item" | cut -d'|' -f1)
            local reason=$(echo "$item" | cut -d'|' -f2-)
            write_report_line "$RED" "[✗] $cmd" "$consolidated_file"
            if [ -n "$reason" ] && [ "$reason" != "null" ]; then
                write_report_line "$YELLOW" "   Motivo: $reason" "$consolidated_file"
            fi
            write_report_line "$NC" "" "$consolidated_file"
        done
        
        # Perguntar se o usuário quer tentar executar novamente de forma interativa
        echo ""
        if [ -t 0 ]; then  # Verificar se está em modo interativo
            print_info "Alguns comandos falharam. Deseja tentar executá-los novamente de forma interativa?"
            echo ""
            echo "1. Sim, tentar executar todos os comandos que falharam"
            echo "2. Não, apenas mostrar os comandos"
            echo "3. Tentar executar comandos individualmente"
            echo ""
            read -p "Escolha uma opção (1-3): " retry_option
            
            case $retry_option in
                1)
                    echo ""
                    print_info "Tentando executar comandos que falharam de forma interativa..."
                    echo ""
                    for item in "${COMMAND_FAILED[@]}"; do
                        local cmd=$(echo "$item" | cut -d'|' -f1)
                        local reason=$(echo "$item" | cut -d'|' -f2-)
                        echo ""
                        print_info "Tentando executar: $cmd"
                        print_info "Motivo da falha anterior: $reason"
                        execute_interactive_user_command "$cmd" "Tentativa interativa após falha: $reason"
                    done
                    ;;
                3)
                    echo ""
                    print_info "Tentando executar comandos individualmente..."
                    echo ""
                    local idx=1
                    for item in "${COMMAND_FAILED[@]}"; do
                        local cmd=$(echo "$item" | cut -d'|' -f1)
                        local reason=$(echo "$item" | cut -d'|' -f2-)
                        echo ""
                        print_info "Comando $idx de ${#COMMAND_FAILED[@]}: $cmd"
                        print_info "Motivo da falha: $reason"
                        read -p "Deseja tentar executar este comando novamente? (s/N): " retry_cmd
                        if [[ "$retry_cmd" =~ ^[SsYy]$ ]]; then
                            execute_interactive_user_command "$cmd" "Tentativa interativa após falha: $reason"
                        else
                            print_info "Pulando comando: $cmd"
                        fi
                        ((idx++))
                    done
                    ;;
                *)
                    print_info "Comandos não serão executados novamente."
                    ;;
            esac
        else
            write_report_line "$NC" "Modo não-interativo: Tente executar os comandos manualmente" "$consolidated_file"
        fi
    else
        write_report_line "$GREEN" "Nenhum comando falhou" "$consolidated_file"
        write_report_line "$NC" "" "$consolidated_file"
    fi
    
    # Comandos que precisam de ação do usuário (AMARELO)
    if [ ${#COMMAND_NEEDS_ACTION[@]} -gt 0 ]; then
        write_report_line "$YELLOW" "======================================================================" "$consolidated_file"
        write_report_line "$YELLOW" "⚠ COMANDOS QUE PRECISAM DE AÇÃO DO USUÁRIO (${#COMMAND_NEEDS_ACTION[@]})" "$consolidated_file"
        write_report_line "$YELLOW" "======================================================================" "$consolidated_file"
        write_report_line "$NC" "" "$consolidated_file"
        
        for item in "${COMMAND_NEEDS_ACTION[@]}"; do
            local cmd=$(echo "$item" | cut -d'|' -f1)
            local reason=$(echo "$item" | cut -d'|' -f2-)
            write_report_line "$YELLOW" "[⚠] $cmd" "$consolidated_file"
            if [ -n "$reason" ] && [ "$reason" != "null" ]; then
                write_report_line "$NC" "   Motivo: $reason" "$consolidated_file"
            fi
            write_report_line "$NC" "" "$consolidated_file"
        done
        
        # Perguntar se o usuário quer executar os comandos interativamente
        echo ""
        if [ -t 0 ]; then  # Verificar se está em modo interativo
            print_info "Deseja executar os comandos que precisam de interação agora?"
            echo ""
            echo "1. Sim, executar todos os comandos interativos"
            echo "2. Não, apenas mostrar os comandos"
            echo "3. Executar comandos individualmente"
            echo ""
            read -p "Escolha uma opção (1-3): " exec_option
            
            case $exec_option in
                1)
                    echo ""
                    print_info "Executando todos os comandos interativos..."
                    echo ""
                    for item in "${COMMAND_NEEDS_ACTION[@]}"; do
                        local cmd=$(echo "$item" | cut -d'|' -f1)
                        local reason=$(echo "$item" | cut -d'|' -f2-)
                        echo ""
                        execute_interactive_user_command "$cmd" "Execução interativa: $reason"
                    done
                    ;;
                3)
                    echo ""
                    print_info "Executando comandos individualmente..."
                    echo ""
                    local idx=1
                    for item in "${COMMAND_NEEDS_ACTION[@]}"; do
                        local cmd=$(echo "$item" | cut -d'|' -f1)
                        local reason=$(echo "$item" | cut -d'|' -f2-)
                        echo ""
                        print_info "Comando $idx de ${#COMMAND_NEEDS_ACTION[@]}: $cmd"
                        read -p "Deseja executar este comando agora? (s/N): " exec_cmd
                        if [[ "$exec_cmd" =~ ^[SsYy]$ ]]; then
                            execute_interactive_user_command "$cmd" "Execução interativa: $reason"
                        else
                            print_info "Pulando comando: $cmd"
                        fi
                        ((idx++))
                    done
                    ;;
                *)
                    print_info "Comandos não serão executados. Execute manualmente quando necessário."
                    ;;
            esac
        else
            write_report_line "$NC" "Modo não-interativo: Execute os comandos manualmente quando necessário" "$consolidated_file"
        fi
    else
        write_report_line "$GREEN" "Nenhum comando requer ação do usuário" "$consolidated_file"
        write_report_line "$NC" "" "$consolidated_file"
    fi
    
    # Resumo final
    write_report_line "$BLUE" "======================================================================" "$consolidated_file"
    write_report_line "$BLUE" "RESUMO" "$consolidated_file"
    write_report_line "$BLUE" "======================================================================" "$consolidated_file"
    write_report_line "$NC" "" "$consolidated_file"
    write_report_line "$GREEN" "Total de comandos executados com sucesso: ${#COMMAND_SUCCESS[@]}" "$consolidated_file"
    write_report_line "$RED" "Total de comandos que falharam: ${#COMMAND_FAILED[@]}" "$consolidated_file"
    write_report_line "$YELLOW" "Total de comandos que precisam de ação: ${#COMMAND_NEEDS_ACTION[@]}" "$consolidated_file"
    write_report_line "$NC" "" "$consolidated_file"
    
    local total_commands=$((${#COMMAND_SUCCESS[@]} + ${#COMMAND_FAILED[@]} + ${#COMMAND_NEEDS_ACTION[@]}))
    write_report_line "$NC" "Total geral de comandos registrados: $total_commands" "$consolidated_file"
    write_report_line "$NC" "" "$consolidated_file"
    
    write_report_line "$BLUE" "======================================================================" "$consolidated_file"
    write_report_line "$BLUE" "FIM DO RELATÓRIO CONSOLIDADO" "$consolidated_file"
    write_report_line "$BLUE" "======================================================================" "$consolidated_file"
    
    echo ""
    print_success "Relatório consolidado salvo em: $consolidated_file"
    print_info "Para visualizar novamente: cat $consolidated_file"
    echo ""
    print_info "Relatório consolidado já foi exibido acima com cores para facilitar a leitura."
    echo ""
}

# Gerar relatório
generate_report() {
    print_header "Gerando Relatório de Diagnóstico"
    
    report_file="nucli-troubleshoot-detailed-report-$(date +%Y%m%d-%H%M%S).txt"
    
    print_info "Criando arquivo de relatório..."
    
    execute_command "date" \
        "Obtém a data e hora atual para incluir no relatório" \
        "false"
    
    {
        echo "Relatório de Troubleshooting NuCLI e AWS (Versão Detalhada)"
        echo "Gerado em: $(date)"
        echo "=========================================="
        echo ""
        echo "Sistema:"
        echo "  OS: $(uname -s)"
        echo "  Versão: $(uname -r)"
        echo "  Hostname: $(hostname)"
        echo ""
        echo "NuCLI:"
        if command -v nu &> /dev/null; then
            echo "  Instalado: Sim"
            echo "  Versão: $(nu --version 2>/dev/null || echo 'N/A')"
        else
            echo "  Instalado: Não"
        fi
        echo ""
        echo "AWS CLI:"
        if command -v aws &> /dev/null; then
            echo "  Instalado: Sim"
            echo "  Versão: $(aws --version 2>/dev/null || echo 'N/A')"
            if aws sts get-caller-identity &> /dev/null; then
                echo "  Credenciais: OK"
                echo "  Conta: $(aws sts get-caller-identity --query Account --output text 2>/dev/null || echo 'N/A')"
            else
                echo "  Credenciais: Não configuradas ou inválidas"
            fi
        else
            echo "  Instalado: Não"
        fi
        echo ""
        echo "Rede:"
        if ping -c 1 8.8.8.8 &> /dev/null; then
            echo "  Conectividade: OK"
        else
            echo "  Conectividade: Problemas detectados"
        fi
        echo ""
        echo "Países/Aliases Disponíveis:"
        countries=("br" "br-staging" "mx" "ist" "us" "us-staging" "co" "ar")
        for country in "${countries[@]}"; do
            echo "  - $country"
        done
        echo ""
        echo "Variáveis de Ambiente:"
        if [ -n "$ENG_POLICIES" ]; then
            echo "  ENG_POLICIES: $ENG_POLICIES"
        else
            echo "  ENG_POLICIES: Não configurada"
        fi
        echo ""
        echo "=========================================="
        echo "COMANDOS ÚTEIS DO NUCLI:"
        echo "=========================================="
        echo ""
        echo "1. Refresh Credenciais AWS:"
        echo "   nu aws shared-role-credentials refresh -i"
        echo ""
        echo "2. Acessar Console Web AWS:"
        echo "   nu aws shared-role-credentials web-console -i"
        echo ""
        echo "3. Ver Políticas IAM:"
        echo "   nu sec shared-role-iam show <username> --target-aws-account=<account-alias>"
        echo "   Exemplo: nu sec shared-role-iam show $(whoami) --target-aws-account=br"
        echo ""
        echo "4. Ver Escopos por País:"
        echo "   nu-br sec scope show <username>"
        echo "   nu-co sec scope show <username>"
        echo "   nu-mx sec scope show <username>"
        echo "   Exemplo: nu-br sec scope show $(whoami)"
        echo "   Nota: Se nu-<pais> não estiver disponível, use:"
        echo "   nu sec scope show <username> --target-aws-account=<pais>"
        echo ""
        echo "5. Gerenciar Políticas Gerenciadas:"
        echo "   Drop: nu aws shared-role-credentials <action> --account-alias=<alias> --drop-policies <policy-names>"
        echo "   Keep: nu aws shared-role-credentials <action> --account-alias=<alias> --keep-policies <policy-names>"
        echo "   Exemplo: nu aws shared-role-credentials refresh --account-alias=br --drop-policies casual-dev,prod-eng"
        echo ""
        echo "6. Gerenciar Políticas Temporárias:"
        echo "   Drop: nu aws shared-role-credentials <action> --account-alias=<alias> --drop-temporary-policies <ids>"
        echo "   Keep: nu aws shared-role-credentials <action> --account-alias=<alias> --keep-temporary-policies <ids>"
        echo "   Drop All: nu aws shared-role-credentials <action> --account-alias=<alias> --drop-all-temporary-policies"
        echo ""
        echo "7. Login Maven/CodeArtifact:"
        echo "   nu codeartifact login maven"
        echo ""
        echo "8. Atualizar NuCLI:"
        echo "   nu update"
        echo ""
        echo "9. Configurar ENG_POLICIES:"
        echo "   echo 'export ENG_POLICIES=<policy-names>' >> ~/.zshrc"
        echo "   Exemplo: echo 'export ENG_POLICIES=casual-dev,prod-eng' >> ~/.zshrc"
        echo ""
        echo "10. Criar Alias para Refresh:"
        echo "   alias aws-br-refresh=\"nu aws shared-role-credentials refresh --account-alias br --keep-policies=\$ENG_POLICIES\""
        echo "   alias aws-br-web=\"nu aws shared-role-credentials web-console --account-alias br --keep-policies=\$ENG_POLICIES\""
        echo ""
        echo "=========================================="
        echo "OBSERVAÇÕES:"
        echo "=========================================="
        echo "- <action> pode ser 'refresh' (CLI) ou 'web-console' (navegador)"
        echo "- <account-alias> pode ser: br, br-staging, mx, ist, us, us-staging, co, ar"
        echo "- <username> é seu nome de usuário (surname)"
        echo "- <policy-names> é uma lista separada por vírgulas, ex: casual-dev,prod-eng"
        echo "- <ids> são IDs de políticas temporárias separados por vírgula, ex: a23d,53rf3"
    } > "$report_file"
    
    execute_command "test -f \"$report_file\"" \
        "Verifica se o arquivo de relatório foi criado com sucesso" \
        "false"
    
    print_success "Relatório salvo em: $report_file"
    print_info "Para visualizar: cat $report_file"
}

# Menu principal
show_menu() {
    echo ""
    print_header "Menu de Troubleshooting (Versão Detalhada)"
    
    # Mostrar status do modo interativo
    if [ "${TRY_INTERACTIVE:-false}" = "true" ]; then
        echo -e "${GREEN}✓ Modo Interativo Automatizado: HABILITADO${NC}"
    else
        echo -e "${YELLOW}⚠ Modo Interativo Automatizado: DESABILITADO${NC}"
        echo -e "${BLUE}   (Para habilitar: export TRY_INTERACTIVE=true)${NC}"
    fi
    echo ""
    
    echo "1. Verificação completa (recomendado)"
    echo "2. Verificar instalação do NuCLI"
    echo "3. Verificar configuração do AWS"
    echo "4. Verificar conectividade de rede"
    echo "5. Verificar variáveis de ambiente"
    echo "6. Verificar permissões de arquivos"
    echo "7. Testar comandos NuCLI"
    echo "8. Testar comandos AWS"
    echo "9. Diagnóstico de problemas comuns"
    echo "10. Verificar roles, escopos e países"
    echo "11. Gerar relatório detalhado"
    echo "12. Gerar relatório final consolidado"
    echo "13. Verificar logs de erro recentes"
    echo "14. Habilitar/Desabilitar modo interativo automatizado"
    echo "0. Sair"
    echo ""
    read -p "Escolha uma opção: " option
    
    case $option in
        1)
            # Limpar arrays de resultados antes de começar
            COMMAND_SUCCESS=()
            COMMAND_FAILED=()
            COMMAND_NEEDS_ACTION=()
            
            check_nucli_installation
            check_aws_config
            check_network_connectivity
            check_environment_variables
            check_file_permissions
            test_nucli_commands
            test_aws_commands
            check_roles_scopes_countries
            diagnose_common_issues
            echo ""
            generate_final_report
            ;;
        2)
            check_nucli_installation
            ;;
        3)
            check_aws_config
            ;;
        4)
            check_network_connectivity
            ;;
        5)
            check_environment_variables
            ;;
        6)
            check_file_permissions
            ;;
        7)
            test_nucli_commands
            ;;
        8)
            test_aws_commands
            ;;
        9)
            diagnose_common_issues
            ;;
        10)
            check_roles_scopes_countries
            ;;
        11)
            generate_report
            ;;
        12)
            # Limpar arrays de resultados antes de gerar relatório
            COMMAND_SUCCESS=()
            COMMAND_FAILED=()
            COMMAND_NEEDS_ACTION=()
            
            generate_final_report
            ;;
        13)
            check_recent_errors
            ;;
        14)
            if [ "${TRY_INTERACTIVE:-false}" = "true" ]; then
                export TRY_INTERACTIVE=false
                print_success "Modo interativo automatizado DESABILITADO"
                print_info "Comandos interativos não serão executados automaticamente"
            else
                export TRY_INTERACTIVE=true
                print_success "Modo interativo automatizado HABILITADO"
                print_info "O script tentará executar comandos interativos com timeout"
                print_warning "Alguns comandos podem ainda precisar de interação manual"
            fi
            ;;
        0)
            echo "Saindo..."
            exit 0
            ;;
        *)
            print_error "Opção inválida"
            ;;
    esac
}

# Função principal
main() {
    # Verificar se está sendo executado interativamente
    if [ -t 0 ]; then
        # Modo interativo
        while true; do
            show_menu
            echo ""
            read -p "Pressione Enter para continuar..."
        done
    else
        # Modo não-interativo - executar verificação completa
        # Limpar arrays de resultados antes de começar
        COMMAND_SUCCESS=()
        COMMAND_FAILED=()
        COMMAND_NEEDS_ACTION=()
        
        check_nucli_installation
        check_aws_config
        check_network_connectivity
        check_environment_variables
        check_file_permissions
        test_nucli_commands
        test_aws_commands
        check_roles_scopes_countries
        diagnose_common_issues
        echo ""
        generate_final_report
    fi
}

# Executar função principal
main

